var mysql = require('mysql');
var express = require("express");
var Connection = require('mysql/lib/Connection');
var bodyParser= require("body-parser");
var encoder = bodyParser.urlencoded();

var app=express();

var con = mysql.createConnection({ 
    host: 'localhost',
    user: 'root',
    password:'artinikode',
    database:'showroomdb'
});
con.connect(function(err)
{
    if (err) throw err;
    else console.log("Connected!");
});

app.get("/",function(req,res){
    res.sendFile(__dirname + "/login.html");
})

app.post("/",encoder,function(req,res){
    var userid = req.body.userid;
    var password = req.body.password;
    Connection.query("select * from users where userid=? and password=? ",[userid,password],function(err,results,fields){
     if (results.length >0){
         res.redirect("/homepage");
     } else{
         res.redirect("/");
     } 
    res.end();
    })      
})

app.get("/homepage",function(req,res){
    res.sendFile(__dirname + "/homepage.html")
})


app.listen(4000);