var mysql = require('mysql');
var express = require("express");
const Connection = require('mysql/lib/Connection');

var app=express();

var con = mysql.createConnection({ 
    host: 'localhost',
    user: 'root',
    password:'artinikode',
    database:'showroomdb'
});
con.connect(function(err)
{
    if (err) throw err;
    console.log("Connected!");
});

app.get("/",function(req,res){
    res.sendFile(__dirname + "/customerregister.html");
})

app.post("/",function(req,res){
    var custid = req.body.custid;
    var password = req.body.password;
    var name = req.body.name;
    var emailid = req.body.password;
    var mobile = req.body.password;
    var address = req.body.password;

    Connection.query("select * from customer where custid=?,password=?,name=?,emailid=?,mobile=?,address=? ",[custid,password,name,emailid,mobile,address],function(err,results,fields){
     if (results.length >0){
         res.redirect("/welcome");
     } else{
         res.redirect("/");
     } 
    res.end();
    })      
})

app.get("/welcome",function(req,res){
    res.sendFile(__dirname + "/welcome.html")
})


app.listen(5501);